// DIALOG
// ======
var dialog = new Window("dialog", undefined, undefined, {independent: true}); 
    dialog.text = "Sequencer"; 
    dialog.orientation = "column"; 
    dialog.alignChildren = ["center","top"]; 
    dialog.spacing = 10; 
    dialog.margins = 16; 

// SEQUENCEFROM
// ============
var SequenceFrom = dialog.add("group", undefined, {name: "SequenceFrom"}); 
    SequenceFrom.orientation = "row"; 
    SequenceFrom.alignChildren = ["left","center"]; 
    SequenceFrom.spacing = 10; 
    SequenceFrom.margins = 0; 
    SequenceFrom.alignment = ["left","top"]; 

var SequenceFromText = SequenceFrom.add("statictext", undefined, undefined, {name: "SequenceFromText"}); 
    SequenceFromText.text = "Sequence from"; 

var SequencerFromDropdown_array = ["Playhead","In Point","Layer Start"]; 
var SequencerFromDropdown = SequenceFrom.add("dropdownlist", undefined, undefined, {name: "SequencerFromDropdown", items: SequencerFromDropdown_array}); 
    SequencerFromDropdown.selection = 0; 

// TIMEUNIT
// ========
var TimeUnit = dialog.add("group", undefined, {name: "TimeUnit"}); 
    TimeUnit.orientation = "row"; 
    TimeUnit.alignChildren = ["left","center"]; 
    TimeUnit.spacing = 10; 
    TimeUnit.margins = 0; 
    TimeUnit.alignment = ["left","top"]; 

var ByText = TimeUnit.add("statictext", undefined, undefined, {name: "ByText"}); 
    ByText.text = "by"; 

var TimeNumber = TimeUnit.add('edittext {properties: {name: "TimeNumber"}}'); 
    TimeNumber.text = "12"; 
    TimeNumber.preferredSize.width = 50; 

var UnitDropdown_array = ["Frames","Seconds"]; 
var UnitDropdown = TimeUnit.add("dropdownlist", undefined, undefined, {name: "UnitDropdown", items: UnitDropdown_array}); 
    UnitDropdown.selection = 0; 

// BUTTONS
// =======
var Buttons = dialog.add("group", undefined, {name: "Buttons"}); 
    Buttons.orientation = "row"; 
    Buttons.alignChildren = ["left","center"]; 
    Buttons.spacing = 0; 
    Buttons.margins = 0; 

// ICONPANEL
// =========
var IconPanel = Buttons.add("panel", undefined, undefined, {name: "IconPanel"}); 
    IconPanel.orientation = "row"; 
    IconPanel.alignChildren = ["left","top"]; 
    IconPanel.spacing = 0; 
    IconPanel.margins = 10; 

var AlignLayers_imgString = "%C2%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%18%00%00%00%18%08%06%00%00%00%C3%A0w%3D%C3%B8%00%00%00%09pHYs%00%00%0B%12%00%00%0B%12%01%C3%92%C3%9D~%C3%BC%00%00%01%C2%88IDATH%C2%89b%C3%BC%C3%BF%C3%BF%3F%03%C3%8D%00%03%03%03%00%00%00%C3%BF%C3%BFbB2%C3%9C%C2%80%C2%81%C2%81%C3%A1%00U-c%60%60%00%00%00%00%C3%BF%C3%BFB%C2%B6%40%C2%80%C2%81%C2%81%C3%81%C2%9E%C2%AA%C2%A6300%00%00%00%00%C3%BF%C3%BFB%C2%B6%C2%80%C3%BA%C2%80%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%C3%82e%01(%C2%A8%40%C2%91C%0An%C3%800%C2%85%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%0F%18%18%18%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BFb%C3%81!%C2%BE%C2%80%C2%8C%24%C2%8B%C2%A9%C2%9E%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%C3%82g%01%C3%A5%C2%80%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%C3%82eA%02%03%03%C2%83%02%C2%916%60M%3D%60%C3%80%C3%80%C3%80%00%00%00%00%C3%BF%C3%BFb%00%15%15P%C3%AC%C3%B0%1F%02%40%C3%AC%03P61%00%C3%99%0CT%C3%BC%C3%BF%3F%03%00%00%00%C3%BF%C3%BF%C2%A2m%24300%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C3%82%15%07%17%C2%A8b%3A%03%03%03%00%00%00%C3%BF%C3%BF%C3%82eA%01ULg%60%60%00%00%00%00%C3%BF%C3%BF%C3%82e%01%C2%A8%C3%A8%06%C2%95%C2%AE%C3%A4%02H%C2%9E%60%60%60%00%00%00%00%C3%BF%C3%BF%C3%82e%C3%81%04%0A%C2%8BnF0%C3%89%C3%80%C3%80%00%00%00%00%C3%BF%C3%BF%C2%A2m%24300%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C3%82%15%07%0ET1%C2%9D%C2%81%C2%81%01%00%00%00%C3%BF%C3%BFB%C3%B6%C3%81%07%06%06%C2%86%C2%83%C3%942%18%0C%18%18%18%00%00%00%00%C3%BF%C3%BF%C2%A2m%C2%B3%C2%85%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%03%00MYq%18%0C%C3%81%C3%A5%C2%96%00%00%00%00IEND%C2%AEB%60%C2%82"; 
var AlignLayers = IconPanel.add("iconbutton", undefined, File.decode(AlignLayers_imgString), {name: "AlignLayers", style: "toolbutton"}); 
    AlignLayers.helpTip = "Align Layers"; 

var SequenceLayers_imgString = "%C2%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%18%00%00%00%18%08%06%00%00%00%C3%A0w%3D%C3%B8%00%00%00%09pHYs%00%00%0B%12%00%00%0B%12%01%C3%92%C3%9D~%C3%BC%00%00%01%C2%ADIDATH%C2%89b%C3%BC%C3%BF%C3%BF%3F%03%C3%8D%00%03%03%03%00%00%00%C3%BF%C3%BFbB2%C3%9C%C2%80%C2%81%C2%81%C3%A1%00U-c%60%60%00%00%00%00%C3%BF%C3%BFB%C2%B6%40%C2%80%C2%81%C2%81%C3%81%C2%9E%C2%AA%C2%A6300%00%00%00%00%C3%BF%C3%BFB%C2%B6%C2%80%C3%BA%C2%80%C2%81%C2%81%01%00%00%00%C3%BF%C3%BFb%C2%A1%C3%90TP%C2%B0N%C3%80%22%5E%C3%80%C3%80%C3%80p%C2%81%C2%81%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%C2%A2%C3%94%02%5C%C3%81%0A%12g%60%60%60%60%00%00%00%00%C3%BF%C3%BF%C2%A2m%10100%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A24%C2%88%1E0004%C3%A2%10g%60%60%60%60%00%00%00%00%C3%BF%C3%BFB%C3%8Eh%0E%0C%0C%0C%C3%BB%19%18%18%18)%C2%B4%14%01%18%18%18%00%00%00%00%C3%BF%C3%BF%22%C3%85%07%20%07%C2%8002%00%C2%B9t%01N%1D%0C%0C%0C%00%00%00%00%C3%BF%C3%BFb%00%C3%B9%00%C2%8A%1D%C3%BEC%00%C2%B2%182n%C2%80%C3%8A%23%C2%83%03x%C3%943%C3%BC%C3%BF%C3%BF%C2%9F%01%00%00%00%C3%BF%C3%BF%C2%A2m%24300%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%22%25%0E%40%C3%A1%7D%10M%0C%C2%9C%5Bq%02%06%06%06%00%00%00%00%C3%BF%C3%BF%C2%A2m*b%60%60%00%00%00%00%C3%BF%C3%BF%C3%82%C3%A5%03P%19%03%C3%8F%C3%AEP%00%C3%B2%01%3C%7D%13%05%18%18%18%00%00%00%00%C3%BF%C3%BF%C3%82%C2%95%C2%8A%40%C2%A9%03%1D%C2%80R%11%C3%9E%14%C2%83%C2%81%C3%BF%C3%BFg%00%00%00%00%C3%BF%C3%BF%C2%A2m%24300%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C3%82%15%C3%89%C3%A8E%02y%C2%80%C2%81%C2%81%01%00%00%00%C3%BF%C3%BFB%C3%B6%C3%81%07%2C%C3%A9%C2%9C2%C3%80%C3%80%C3%80%00%00%00%00%C3%BF%C3%BF%C2%A2m%C2%B3%C2%85%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%03%00%2C%C3%BF%C2%B8%C3%92%C2%8Fl%C2%AD%3E%00%00%00%00IEND%C2%AEB%60%C2%82"; 
var SequenceLayers = IconPanel.add("iconbutton", undefined, File.decode(SequenceLayers_imgString), {name: "SequenceLayers", style: "toolbutton"}); 
    SequenceLayers.helpTip = "Sequence Layers"; 

var DistributeLayers_imgString = "%C2%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%18%00%00%00%18%08%06%00%00%00%C3%A0w%3D%C3%B8%00%00%00%09pHYs%00%00%0B%12%00%00%0B%12%01%C3%92%C3%9D~%C3%BC%00%00%01%C2%82IDATH%C2%89b%C3%BC%C3%BF%C3%BF%3F%03%C3%8D%00%03%03%03%00%00%00%C3%BF%C3%BFbB2%C3%9C%C2%80%C2%81%C2%81%C3%A1%00U-c%60%60%00%00%00%00%C3%BF%C3%BFB%C2%B6%40%C2%80%C2%81%C2%81%C3%81%C2%9E%C2%AA%C2%A6300%00%00%00%00%C3%BF%C3%BFB%C2%B6%C2%80%C3%BA%C2%80%C2%81%C2%81%01%00%00%00%C3%BF%C3%BFb!%C3%81%C3%94%04(%26%068%C2%80%15100%00%00%00%00%C3%BF%C3%BF%22%C3%85%02%05%C2%92%C2%83%C2%90%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%C2%A2m%10100%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%22%25%C2%88HO%C3%82%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%22%C3%95%02%C3%92%2Ca%60%60%00%00%00%00%C3%BF%C3%BF%22d%01(b%C2%89M9%C2%98%0E%60%60%60%00%00%00%00%C3%BF%C3%BF%22%C3%86%C2%82z%22-%C2%80Y%C2%82%00%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2m%24300%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%22%14D%1F%18%18%18%0E%12i%C3%96%03%0C%11%06%06%06%00%00%00%00%C3%BF%C3%BF%22d%C3%81%05%C3%A4lO2%60%60%60%00%00%00%00%C3%BF%C3%BF%C3%82e%01%C2%A8%C3%A8%06%C2%95%C2%AE%C3%84%00%C3%9CI%C2%97%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%C3%82e%C3%81%04%12%C3%8A%1DF%C2%9C2%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2m%24300%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C3%82%15%07%14%C2%A5%1C8%60%60%60%00%00%00%00%C3%BF%C3%BFB%C3%B6%01)i%C2%9E8%C3%80%C3%80%C3%80%00%00%00%00%C3%BF%C3%BF%C2%A2m%C2%B3%C2%85%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%03%00r%C3%B0%15%C3%9EKA%1A%C2%B9%00%00%00%00IEND%C2%AEB%60%C2%82"; 
var DistributeLayers = IconPanel.add("iconbutton", undefined, File.decode(DistributeLayers_imgString), {name: "DistributeLayers", style: "toolbutton"}); 
    DistributeLayers.helpTip = "Distribute Layers"; 

var RandomizeLayers_imgString = "%C2%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%18%00%00%00%18%08%06%00%00%00%C3%A0w%3D%C3%B8%00%00%00%09pHYs%00%00%0B%12%00%00%0B%12%01%C3%92%C3%9D~%C3%BC%00%00%01%C2%95IDATH%C2%89b%C3%BC%C3%BF%C3%BF%3F%03%C3%8D%00%03%03%03%00%00%00%C3%BF%C3%BFbB2%C3%9C%C2%80%C2%81%C2%81%C3%A1%00U-c%60%60%00%00%00%00%C3%BF%C3%BFB%C2%B6%40%C2%80%C2%81%C2%81%C3%81%C2%9E%C2%AA%C2%A6300%00%00%00%00%C3%BF%C3%BFB%C2%B6%C2%80%C3%BA%C2%80%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%22d%C2%81%03%03%03%03(%C2%92%C2%88%C3%81%0D%18%C2%BA%19%18%18%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%0F%18%18%18%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BFb!%20%C3%BF%C2%80%C2%81%C2%81%C2%A1%C2%91H%C2%B30%C2%938%03%03%03%00%00%00%C3%BF%C3%BFB%C3%8Eh%C2%A0%08%C3%9D%C3%8F%C3%80%C3%80%C3%80H%C2%92%13%C3%B1%01%06%06%06%00%00%00%00%C3%BF%C3%BF%22%C3%A4%03d%00r%00%08%13%03%20)%C2%8A%C2%81%C2%81%01%00%00%00%C3%BF%C3%BFb%00%C3%B9%00%C2%8A%1D%C3%BEC%00%C2%B2%182n%C2%80%C3%8A%13%03%20%C3%BA%C3%BE%C3%BFg%00%00%00%00%C3%BF%C3%BF%C2%A2m%24300%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%22%25%0E%40)%C3%AA%20I%C2%A6300%00%00%00%00%C3%BF%C3%BF%C2%A2m*b%60%60%00%00%00%00%C3%BF%C3%BF%C3%82%C3%A5%03P%C3%91%0D*%5D%C2%89%01%C2%B8%C2%8Bx%06%06%06%00%00%00%00%C3%BF%C3%BF%C3%82e%C3%81%04%12%C2%8An%C3%9C%3Ef%60%60%00%00%00%00%C3%BF%C3%BF%C2%A2m%24300%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C3%82%15%07%C3%84%16%09%C3%B8%01%03%03%03%00%00%00%C3%BF%C3%BFB%C3%B6%C3%81%07r%C3%929%5E%C3%80%C3%80%C3%80%00%00%00%00%C3%BF%C3%BF%C2%A2m%C2%B3%C2%85%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%03%00%C2%8Fnv%10%C2%91%0B%10N%00%00%00%00IEND%C2%AEB%60%C2%82"; 
var RandomizeLayers = IconPanel.add("iconbutton", undefined, File.decode(RandomizeLayers_imgString), {name: "RandomizeLayers", style: "toolbutton"}); 
    RandomizeLayers.helpTip = "Randomize Layers"; 

var divider = IconPanel.add("panel", undefined, undefined, {name: "divider"}); 
    divider.alignment = "fill"; 

var ReverseSequence_imgString = "%C2%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%18%00%00%00%18%08%06%00%00%00%C3%A0w%3D%C3%B8%00%00%00%09pHYs%00%00%0B%12%00%00%0B%12%01%C3%92%C3%9D~%C3%BC%00%00%01%C2%99IDATH%C2%89b%C3%BC%C3%BF%C3%BF%3F%03%C3%8D%00%03%03%03%00%00%00%C3%BF%C3%BFb%22%C3%91%C3%B0%04(%26%0E000%00%00%00%00%C3%BF%C3%BFb!%C3%91%02%05%C2%92T300%00%00%00%00%C3%BF%C3%BF%22%C3%95%07%C2%A4%01%06%06%06%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BFB%C2%B7%C2%A0%C2%81%C2%81%C2%81%C3%A1%009%C3%89%11%C2%AA%07%C2%A4%17d%06%04000%00%00%00%00%C3%BF%C3%BF%C3%82%C3%A6%03%7B%06%06%C2%86%C3%BBP%C2%85%02D%18%0CR%03R%0B%C3%92%03%C3%92%C2%8B%00%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C3%82%17D%C3%B5%0C%0C%0C%0F%08%C3%A4%5C%C2%90%1CH%0DH-%26%60%60%60%00%00%00%00%C3%BF%C3%BF%C2%A2m%1C000%00%00%00%00%C3%BF%C3%BF%C3%82gA%234%5C%17%C3%A0Q%03%C2%92%03%C2%A9%01%C2%A9%C3%85%04%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C3%82f%C3%81A%06%06%06Eh%C2%B8~%20%C3%82%C2%91%205%20%C2%B5%20%3D%20%C2%BD%08%C3%80%C3%80%C3%80%00%00%00%00%C3%BF%C3%BFB%2F%C3%ACPR%00%C2%89%00%14%17%0E(z%18%18%18%00%00%00%00%C3%BF%C3%BF%C2%A2m%1C000%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%C2%A2%C2%AD%05%0C%0C%0C%00%00%00%00%C3%BF%C3%BF%22%C2%B5N%06%25E%C3%A2%01%03%03%03%00%00%00%C3%BF%C3%BF%C2%A2m%C2%B3%C2%85%C2%81%C2%81%01%00%00%00%C3%BF%C3%BF%03%00%C3%84%C2%81%1AO%C2%87H%C3%A3%25%00%00%00%00IEND%C2%AEB%60%C2%82"; 
var ReverseSequence = IconPanel.add("iconbutton", undefined, File.decode(ReverseSequence_imgString), {name: "ReverseSequence", style: "toolbutton"}); 
    ReverseSequence.enabled = false; 
    ReverseSequence.helpTip = "Reverse Sequence"; 

var reverseAction = "";
//Align Layers =========================================================
// =====================================================================
function alignButton() {
    var comp = app.project.activeItem;
    var frameRate = comp.frameRate;
    var inPointCase = SequencerFromDropdown.selection.text;
    var tUnit = UnitDropdown.selection.text;

      if (!(comp && comp instanceof CompItem)) {
          alert("ERROR: No composition is selected");
          return;
      }

      var selectedLayers = comp.selectedLayers;
      
      if (selectedLayers.length === 0) {
          alert("ERROR: No layers are selected");
          return;
      }

      var frameOffset = parseFloat(TimeNumber.text);
      
      
      if(tUnit == "Frames"){
                  var outPoint = (frameOffset/frameRate);
     }else{
                  var outPoint = frameOffset;
      }
      
      app.beginUndoGroup("Align Layers");
          
      for (var i = 0; i < selectedLayers.length; i++) {
        var layer = selectedLayers[i];
        if (inPointCase == "Playhead"){
            var inPoint = comp.time;
        }
        else if (inPointCase == "In Point") {
            var inPoint = comp.workAreaStart;
        } else {
            var inPoint = selectedLayers[0].inPoint;
        }
        var trimming = layer.inPoint - layer.startTime;
        layer.startTime = inPoint - trimming;
      }

      app.endUndoGroup();
      reverseAction = "align";
      ReverseSequence.enabled = false; 
   }
//Sequence Layers ========================================
// =======================================================
function sequencerButton() {
    var comp = app.project.activeItem;
    var inPointCase = SequencerFromDropdown.selection.text;

                if (!(comp && comp instanceof CompItem)) {
                    alert("ERROR: No composition is selected");
                return;
                }

                var selectedLayers = comp.selectedLayers;
                if (selectedLayers.length === 0) {
                    alert("ERROR: No layers are selected");
                    return;
                }

                if (inPointCase == "Playhead"){
                    var inPoint = comp.time;
                }
                else if (inPointCase == "In Point") {
                    var inPoint = comp.workAreaStart;
                } else {
                    var inPoint = selectedLayers[0].inPoint;
                }

                app.beginUndoGroup("Sequence Layers");
                try {
                    var layerV = selectedLayers[0];
                    layerV.startTime = inPoint + (layerV.startTime - layerV.inPoint); 
                    
                    for (var i = 1; i < selectedLayers.length; i++) {
                        var previousLayer = selectedLayers[i - 1];
                        var currentLayer = selectedLayers[i];
                        var trimming = currentLayer.startTime - currentLayer.inPoint;

                        currentLayer.startTime = previousLayer.outPoint + trimming;
                    }
                } finally {
                    app.endUndoGroup();
                }

                reverseAction = "sequence";
                ReverseSequence.enabled = true; 
}

//Randomly Space Layers ===============================
// ====================================================
function sequenceRandom() {
    var comp = app.project.activeItem;
    var frameRate = comp.frameRate;
    var inPointCase = SequencerFromDropdown.selection.text;
    var tUnit = UnitDropdown.selection.text;

            if (!(comp && comp instanceof CompItem)) {
                alert("ERROR: No composition is selected");
                return;
            }

            var selectedLayers = comp.selectedLayers;
            if (selectedLayers.length === 0) {
                alert("ERROR: No layers are selected");
                return;
            }
 
            var frameOffset = parseFloat(TimeNumber.text);
            if (isNaN(frameOffset) || frameOffset < 0) {
                alert("ERROR: Duration must be a valid positive number");
            return;
            }
            
            if(tUnit == "Frames"){
                        var outPoint = (frameOffset/frameRate);
           }else{
                        var outPoint = frameOffset;
            }

            app.beginUndoGroup("Randomly Distribute Layers");
                
            for (var i = 0; i < selectedLayers.length; i++) {
                var layer = selectedLayers[i];
                if (inPointCase == "Playhead"){
                    var inPoint = comp.time;
                }
                else if (inPointCase == "In Point") {
                    var inPoint = comp.workAreaStart;
                } else {
                    var inPoint = layer.inPoint;
                }
                var trimming = layer.startTime - layer.inPoint;
                var randomTime = inPoint + Math.random(0,1) * (outPoint);
                layer.startTime = randomTime + trimming;
            }

            app.endUndoGroup();
            
            reverseAction = "random";
            ReverseSequence.enabled = false; 
   }

// Equally Space Layers ================================
// =====================================================

function sequenceEqual() {
    var comp = app.project.activeItem;
          
          if (!(comp && comp instanceof CompItem)) {
            alert("ERROR: No composition is selected");
          return;
          }
      
          var frameRate = comp.frameRate;
          var inPointCase = SequencerFromDropdown.selection.text;
          var tUnit = UnitDropdown.selection.text;

            var selectedLayers = comp.selectedLayers;
            
            if (selectedLayers.length === 0) {
                alert("ERROR: No layers are selected");
                return;
            }
        
            var frameOffset = parseFloat(TimeNumber.text);
             if (isNaN(frameOffset) || frameOffset <= 0) {
                alert("ERROR: Duration must be a valid positive number");
            return;
            }
            
            if(tUnit == "Frames"){
                        var outPoint = frameOffset;
           }else{
                        var outPoint = frameOffset*frameRate;
            }

            app.beginUndoGroup("Equally Distribute Layers");
                
            for (var i = 0; i < selectedLayers.length; i++) {
                var layer = selectedLayers[i];
                if (inPointCase == "Playhead"){
                    var inPoint = comp.time;
                }
                else if (inPointCase == "In Point") {
                    var inPoint = comp.workAreaStart;
                } else {
                    var inPoint = selectedLayers[0].inPoint;
                }
                var trimming = layer.startTime - layer.inPoint;
// Change Function
//============
                var equalTime = (outPoint/(selectedLayers.length-1))*(i);
                var equalFrames = equalTime/frameRate;
                layer.startTime = inPoint + equalFrames + trimming;
            }

            app.endUndoGroup();
            
            reverseAction = "equal";
            ReverseSequence.enabled = true; 
   }

// Flip Function ======================================
//=====================================================

function flipButton() {
    var comp = app.project.activeItem;
          
    if (!(comp && comp instanceof CompItem)) {
        alert("ERROR: No composition is selected");
    return;
    }

    var frameRate = comp.frameRate;
    var inPointCase = SequencerFromDropdown.selection.text;
    var tUnit = UnitDropdown.selection.text;

    var selectedLayers = comp.selectedLayers;
    
    if (selectedLayers.length === 0) {
        alert("ERROR: No layers are selected");
        return;
    }

    var frameOffset = parseFloat(TimeNumber.text);
     if (isNaN(frameOffset) || frameOffset <= 0) {
        alert("ERROR: Duration must be a valid positive number");
    return;
    }
    
    if(tUnit == "Frames"){
                var outPoint = frameOffset;
   }else{
                var outPoint = frameOffset*frameRate;
    }

    if (inPointCase == "Playhead"){
        var inPoint = comp.time;
    }
    else if (inPointCase == "In Point") {
        var inPoint = comp.workAreaStart;
    } else {
        var inPoint = selectedLayers[0].inPoint;
    }

    app.beginUndoGroup("reverse action");
        if(reverseAction == "equal") {
    for (var i = 0; i < selectedLayers.length; i++) {
        var layer = selectedLayers[i];
        var trimming = layer.startTime - layer.inPoint;
        var equalTime = (outPoint/(selectedLayers.length-1))*(selectedLayers.length-(i+1));
        var equalFrames = equalTime/frameRate;
        layer.startTime = inPoint + equalFrames + trimming;
    }
    };
        if (reverseAction == "sequence"){
        var layerV = selectedLayers[selectedLayers.length - 1]; // Start with the last selected layer
        layerV.startTime = inPoint + (layerV.startTime - layerV.inPoint);

        for (var i = selectedLayers.length - 2; i >= 0; i--) { // Iterate in reverse
            var previousLayer = selectedLayers[i + 1];
            var currentLayer = selectedLayers[i];
            var trimming = currentLayer.startTime - currentLayer.inPoint;

            currentLayer.startTime = previousLayer.outPoint + trimming;
    }
    };
    ReverseSequence.enabled = false; 

    app.endUndoGroup();
}

AlignLayers.onClick = alignButton;
SequenceLayers.onClick = sequencerButton;
DistributeLayers.onClick = sequenceEqual;
RandomizeLayers.onClick = sequenceRandom;
ReverseSequence.onClick = flipButton;

dialog.show();

//Script by Tucker Ziegler
//www.tuckerziegler.com
//Reach out with work to tuckerziegler25@gmail.com